from selenium import webdriver
from selenium.webdriver.common.by import By
import json

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://books.toscrape.com")

books = []
for page in range(1, 6):
    print(f"Парсим страницу {page}...")
    articles = driver.find_elements(By.CSS_SELECTOR, "article.product_pod")
    for article in articles:
        title = article.find_element(By.CSS_SELECTOR, "h3 a").get_attribute("title")
        price = article.find_element(By.CSS_SELECTOR, ".price_color").text
        stock = article.find_element(By.CSS_SELECTOR, ".availability").text.strip()

        books.append({
            "title": title,
            "price": price,
            "stock": stock
        })
    
   
    try:
        next_link = driver.find_element(By.LINK_TEXT, "next")
        next_link.click()
    except:
        break


with open("books.json", "w", encoding="utf-8") as f:
    json.dump(books, f, ensure_ascii=False, indent=4)


for book in books:
    if book["title"] == "Thirst":
        driver.get("http://books.toscrape.com")
        for _ in range(5):
            try:
                thirst_el = driver.find_element(By.XPATH, '//a[@title="Thirst"]')
                thirst_el.click()
                driver.save_screenshot("thirst_book.png")
                break
            except:
                try:
                    driver.find_element(By.LINK_TEXT, "next").click()
                except:
                    break
        break

driver.quit()